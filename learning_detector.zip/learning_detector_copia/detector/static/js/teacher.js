document.addEventListener('DOMContentLoaded', () => {
    const groupSelect = document.getElementById('group-select');
    const getRecommendationsButton = document.getElementById('get-recommendations-button');
    const recommendationsDiv = document.getElementById('recommendations');

    // Simulación de datos de estilos de aprendizaje de los estudiantes por grupo
    const groupData = {
        grupoA: { visual: 40, auditivo: 35, kinestesico: 25 },
        grupoB: { visual: 30, auditivo: 50, kinestesico: 20 },
        grupoC: { visual: 25, auditivo: 20, kinestesico: 55 }
    };

    // Habilitar el botón "Obtener Recomendaciones" al seleccionar un grupo
    groupSelect.addEventListener('change', () => {
        getRecommendationsButton.disabled = groupSelect.value === '';
    });

    // Generar recomendaciones al hacer clic en "Obtener Recomendaciones"
    getRecommendationsButton.addEventListener('click', () => {
        const selectedGroup = groupSelect.value;
        const groupLearningStyles = groupData[selectedGroup];

        let recommendations = `<h3>Recomendaciones para ${selectedGroup}:</h3><ul>`;

        // Basado en los porcentajes, se dan recomendaciones específicas
        if (groupLearningStyles.visual > groupLearningStyles.auditivo && groupLearningStyles.visual > groupLearningStyles.kinestesico) {
            recommendations += "<li>Utilizar recursos visuales como mapas mentales, gráficos, y diagramas para las actividades.</li>";
            recommendations += "<li>Recomendar lecturas con apoyo de ilustraciones y presentaciones visuales.</li>";
        }
        if (groupLearningStyles.auditivo > groupLearningStyles.visual && groupLearningStyles.auditivo > groupLearningStyles.kinestesico) {
            recommendations += "<li>Utilizar explicaciones en audio y actividades de discusión grupal.</li>";
            recommendations += "<li>Fomentar el uso de audiolibros y podcasts como material complementario.</li>";
        }
        if (groupLearningStyles.kinestesico > groupLearningStyles.visual && groupLearningStyles.kinestesico > groupLearningStyles.auditivo) {
            recommendations += "<li>Proponer actividades prácticas y experimentales.</li>";
            recommendations += "<li>Incluir tareas que involucren movimientos físicos y manualidades para aprender conceptos.</li>";
        }

        recommendations += "</ul>";
        recommendationsDiv.innerHTML = recommendations;
        recommendationsDiv.style.display = 'block';
    });
});
