// Simulación de datos del estudiante
const studentName = "Juan Pérez"; // Reemplaza por una variable dinámica
const studentGroup = "Grupo A"; // Reemplaza por una variable dinámica

// Insertar datos en el HTML
document.getElementById("student-name").textContent = studentName;
document.getElementById("student-group").textContent = studentGroup;

// Verificar si el test ya ha sido completado y mostrar resultados
function loadTestStatus() {
  const testCompleted = localStorage.getItem("testCompleted");
  if (testCompleted === "true") {
    // Mostrar los resultados del test
    const visualPercentage = localStorage.getItem("visualPercentage");
    const auditivoPercentage = localStorage.getItem("auditivoPercentage");
    const kinestesicoPercentage = localStorage.getItem("kinestesicoPercentage");

    document.getElementById("results").innerHTML = `
            <h3>Resultados del Test:</h3>
            <p>Visual: ${visualPercentage}%</p>
            <p>Auditivo: ${auditivoPercentage}%</p>
            <p>Kinestésico: ${kinestesicoPercentage}%</p>
        `;

    // Habilitar botón de recomendaciones y deshabilitar el botón de test
    document.getElementById("test-button").disabled = true;
    document.getElementById("recommendations-button").disabled = false;
  } else {
    // Si el test no se ha hecho, deshabilitar recomendaciones y habilitar el botón de test
    document.getElementById("test-button").disabled = false;
    document.getElementById("recommendations-button").disabled = true;
    document.getElementById("results").innerHTML = "";
  }
}

// Función para mostrar recomendaciones basadas en los resultados
function showRecommendations() {
  const visualPercentage = localStorage.getItem("visualPercentage");
  const auditivoPercentage = localStorage.getItem("auditivoPercentage");
  const kinestesicoPercentage = localStorage.getItem("kinestesicoPercentage");

  let recommendations = "<h3>Recomendaciones:</h3><ul>";
  if (
    visualPercentage > auditivoPercentage &&
    visualPercentage > kinestesicoPercentage
  ) {
    recommendations +=
      "<li>Utiliza diagramas, mapas mentales y gráficos para estudiar.</li>";
    recommendations += "<li>Visualiza imágenes para recordar información.</li>";
  } else if (
    auditivoPercentage > visualPercentage &&
    auditivoPercentage > kinestesicoPercentage
  ) {
    recommendations +=
      "<li>Escucha explicaciones en audio y repite en voz alta.</li>";
    recommendations +=
      "<li>Usa grabaciones y podcasts para reforzar el aprendizaje.</li>";
  } else if (
    kinestesicoPercentage > visualPercentage &&
    kinestesicoPercentage > auditivoPercentage
  ) {
    recommendations +=
      "<li>Practica actividades físicas o experimentales.</li>";
    recommendations +=
      "<li>Utiliza ejemplos y actividades prácticas para reforzar conceptos.</li>";
  }
  recommendations += "</ul>";

  document.getElementById("results").innerHTML = recommendations;
}

// Cargar el estado del test al cargar la página
loadTestStatus();

// Borrar el estado del test al cargar la página (reset automático)
//localStorage.removeItem("testCompleted");
//localStorage.removeItem("visualPercentage");
//localStorage.removeItem("auditivoPercentage");
//localStorage.removeItem("kinestesicoPercentage");

