document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('learning-style-form');
    const resultDiv = document.getElementById('result');
    const backButton = document.getElementById('back-button'); // Obtener el botón de regreso

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const formData = new FormData(form);
        const answers = Array.from(formData.values());

        // Inicializar los contadores para cada estilo
        const counts = {
            visual: 0,
            auditivo: 0,
            kinestesico: 0
        };

        // Contar cada respuesta en su estilo correspondiente
        answers.forEach(answer => {
            if (counts.hasOwnProperty(answer)) {
                counts[answer]++;
            }
        });

        // Calcular porcentajes
        const total = answers.length;
        const visualPercentage = total ? ((counts.visual / total) * 100).toFixed(2) : 0;
        const auditivoPercentage = total ? ((counts.auditivo / total) * 100).toFixed(2) : 0;
        const kinestesicoPercentage = total ? ((counts.kinestesico / total) * 100).toFixed(2) : 0;

        // Guardar los resultados en localStorage
        localStorage.setItem('testCompleted', 'true');
        localStorage.setItem('visualPercentage', visualPercentage);
        localStorage.setItem('auditivoPercentage', auditivoPercentage);
        localStorage.setItem('kinestesicoPercentage', kinestesicoPercentage);

        // Mostrar los resultados en la página del test
        resultDiv.innerHTML = `
            <p><strong>Resultados:</strong></p>
            <p>Visual: ${visualPercentage}%</p>
            <p>Auditivo: ${auditivoPercentage}%</p>
            <p>Kinestésico: ${kinestesicoPercentage}%</p>
        `;
        resultDiv.style.display = 'block';

        // Mostrar el botón de regreso
        backButton.style.display = 'inline-block';

        // Reiniciar el formulario para permitir otra prueba si se desea
        form.reset();
    });
});
