from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

# Nueva vista para la página del test
def test_learning_style(request):
    return render(request, 'test.html')  # Renderiza la plantilla del test

def login(request):
    return render(request,'login.html')

def student(request):
    return render(request,'student.html')

def teacher(request):
    return render(request,'teacher.html')