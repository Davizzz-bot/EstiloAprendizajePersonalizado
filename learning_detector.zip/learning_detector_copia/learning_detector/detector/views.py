from django.shortcuts import render

def index(request):
    return render(request, 'detector/index.html')

# Nueva vista para la página del test
def test_learning_style(request):
    return render(request, 'detector/test.html')  # Renderiza la plantilla del test
