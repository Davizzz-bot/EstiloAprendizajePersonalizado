// Función para mostrar el nombre del archivo seleccionado
function showFileName() {
  const input = document.getElementById("fileInput");
  const fileNameField = document.getElementById("fileName");

  if (input.files.length > 0) {
    fileNameField.value = input.files[0].name; // Muestra el nombre del archivo
  } else {
    fileNameField.value = ""; // Si no hay archivo seleccionado, borra el texto
  }
}

// Función para procesar los datos (simulación)
function processData() {
  alert("Datos cargados y procesados");
  displayChart();
  showRecommendations();
}

// Función para mostrar el gráfico de estilos de aprendizaje
function displayChart() {
  const ctx = document.getElementById("learningStyleChart").getContext("2d");
  const chart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: ["Visual", "Auditivo", "Kinestésico"],
      datasets: [
        {
          label: "Estilo de Aprendizaje",
          data: [60, 30, 10], // Datos simulados
          backgroundColor: [
            "rgba(54, 162, 235, 0.6)",
            "rgba(255, 206, 86, 0.6)",
            "rgba(75, 192, 192, 0.6)",
          ],
          borderColor: [
            "rgba(54, 162, 235, 1)",
            "rgba(255, 206, 86, 1)",
            "rgba(75, 192, 192, 1)",
          ],
          borderWidth: 1,
        },
      ],
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}

// Función para mostrar recomendaciones
function showRecommendations() {
  const recommendations = `
      <ul>
        <li><strong>Visual:</strong> Videos explicativos y presentaciones gráficas.</li>
        <li><strong>Auditivo:</strong> Podcasts y audiolibros.</li>
        <li><strong>Kinestésico:</strong> Actividades prácticas y simulaciones interactivas.</li>
      </ul>
    `;
  document.getElementById("recommendations").innerHTML = recommendations;
}

function validateTest() {
  alert("validateTest se está ejecutando"); // Confirmación
  const questions = document.querySelectorAll(".question");
  let allAnswered = false;

  questions.forEach((question) => {
    const options = question.querySelectorAll('input[type="radio"]');
    let answered = false;

    options.forEach((option) => {
      if (option.checked) {
        answered = true;
      }
      if (answered == true) {
        allAnswered = true;
      } else {
        allAnswered = false;
      }
    });

    if (allAnswered==true) {
      processData();
    } else {
      alert(
        "hay preguntas sin responder, vuelva a revisar"
      );
    }
  });
}
